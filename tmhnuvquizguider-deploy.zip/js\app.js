/**
 * Main Application Orchestrator
 * Tab routing, modals, dark mode, toast alerts, interactive learning tools,
 * author & school showcase (Done By), and canvas celebration confetti.
 */

const App = {
  activeTab: 'home',
  darkMode: false,

  init() {
    this.initTheme();
    this.bindNavigation();
    this.renderAnnouncements();
    this.renderCourses();
    this.renderResources();
    this.renderDoneBy();
    this.renderOurSchool();

    if (window.Auth) window.Auth.init();
    if (window.QuizEngine) window.QuizEngine.init();
    if (window.AdminPortal) window.AdminPortal.init();

    window.addEventListener('auth-changed', () => {
      this.updateTabVisibility();
      if (window.AdminPortal) window.AdminPortal.renderAdminDashboard();
      if (window.QuizEngine) window.QuizEngine.renderLeaderboard();
    });

    console.log("School Stall Educational Platform Loaded Successfully.");
  },

  initTheme() {
    const savedTheme = localStorage.getItem('edunova_theme');
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    if (savedTheme === 'dark' || (!savedTheme && prefersDark)) {
      this.setTheme(true);
    } else {
      this.setTheme(false);
    }
  },

  setTheme(isDark) {
    this.darkMode = isDark;
    if (isDark) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('edunova_theme', 'dark');
      const icon = document.getElementById('theme-toggle-icon');
      if (icon) icon.textContent = '☀️';
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('edunova_theme', 'light');
      const icon = document.getElementById('theme-toggle-icon');
      if (icon) icon.textContent = '🌙';
    }
  },

  toggleTheme() {
    this.setTheme(!this.darkMode);
  },

  bindNavigation() {
    document.querySelectorAll('[data-tab-target]').forEach(button => {
      button.addEventListener('click', (e) => {
        const target = button.getAttribute('data-tab-target');
        this.switchTab(target);
      });
    });
  },

  switchTab(tabId) {
    this.activeTab = tabId;

    document.querySelectorAll('[data-tab-target]').forEach(btn => {
      if (btn.getAttribute('data-tab-target') === tabId) {
        btn.classList.add('active', 'bg-indigo-600', 'text-white');
        btn.classList.remove('text-slate-600', 'dark:text-slate-300', 'hover:bg-slate-100');
      } else {
        btn.classList.remove('active', 'bg-indigo-600', 'text-white');
        btn.classList.add('text-slate-600', 'dark:text-slate-300', 'hover:bg-slate-100');
      }
    });

    document.querySelectorAll('.tab-view-content').forEach(view => {
      view.classList.add('hidden');
    });

    const targetEl = document.getElementById(`tab-content-${tabId}`);
    if (targetEl) {
      targetEl.classList.remove('hidden');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    if (tabId === 'admin' && window.AdminPortal) {
      window.AdminPortal.renderAdminDashboard();
    }
  },

  updateTabVisibility() {
    const adminTabBtn = document.getElementById('nav-admin-tab');
    if (adminTabBtn) {
      if (window.Auth && window.Auth.isAdmin()) {
        adminTabBtn.classList.remove('hidden');
      } else {
        adminTabBtn.classList.add('hidden');
        if (this.activeTab === 'admin') {
          this.switchTab('home');
        }
      }
    }
  },

  renderAnnouncements() {
    const container = document.getElementById('platform-announcements-container');
    if (!container) return;

    const announcements = window.AdminPortal ? window.AdminPortal.getAnnouncements() : (window.AppData ? window.AppData.announcements : []);
    container.innerHTML = announcements.map(ann => `
      <div class="glass-panel p-5 border-l-4 ${ann.pinned ? 'border-l-amber-500' : 'border-l-indigo-600'} hover:shadow-lg transition">
        <div class="flex items-center justify-between gap-2 mb-2">
          <span class="badge-tag ${ann.pinned ? 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300' : 'bg-indigo-100 text-indigo-800 dark:bg-indigo-950/60 dark:text-indigo-300'}">
            ${ann.tag}
          </span>
          <span class="text-xs text-slate-400 font-medium">${ann.date}</span>
        </div>
        <h4 class="font-bold text-base mb-1.5">${ann.title}</h4>
        <p class="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">${ann.content}</p>
      </div>
    `).join('');
  },

  renderCourses() {
    const container = document.getElementById('courses-grid-container');
    if (!container) return;

    const courses = window.AppData ? window.AppData.courses : [];
    container.innerHTML = courses.map(c => `
      <div class="glass-panel p-6 flex flex-col justify-between hover:-translate-y-1 transition-all duration-300 group">
        <div>
          <div class="w-12 h-12 rounded-xl bg-gradient-to-tr ${c.color} text-white flex items-center justify-center font-bold text-xl mb-4 shadow-lg group-hover:scale-110 transition-transform">
            ${c.category[0]}
          </div>
          <span class="badge-tag bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 mb-2">${c.category}</span>
          <h3 class="text-xl font-bold mb-2">${c.title}</h3>
          <p class="text-sm text-slate-500 dark:text-slate-400 mb-4">${c.description}</p>
          <div class="text-xs text-slate-500 dark:text-slate-400 flex items-center justify-between border-t border-slate-100 dark:border-slate-800 pt-3 mb-5">
            <span>📚 ${c.lessonsCount} Core Modules</span>
            <span>⭐ ${c.level}</span>
          </div>
        </div>
        <button onclick="App.openCourseLessons('${c.id}')" class="w-full py-2.5 px-4 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg shadow transition flex items-center justify-center gap-2">
          <span>Explore Modules</span>
          <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
        </button>
      </div>
    `).join('');
  },

  openCourseLessons(courseId) {
    const courses = window.AppData ? window.AppData.courses : [];
    const course = courses.find(c => c.id === courseId);
    if (!course) return;

    const modalTitle = document.getElementById('course-modal-title');
    const modalDesc = document.getElementById('course-modal-desc');
    const lessonsList = document.getElementById('course-modal-lessons');

    modalTitle.textContent = course.title;
    modalDesc.textContent = course.description;

    lessonsList.innerHTML = course.lessons.map((les, index) => `
      <div class="p-5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800/80 mb-4">
        <div class="flex items-center justify-between mb-2">
          <span class="text-xs font-bold px-2 py-0.5 rounded bg-indigo-100 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300">
            Module ${index + 1}
          </span>
          <span class="text-xs text-slate-400">${les.interactiveTool ? '⚡ Interactive Lab' : '📖 Theory'}</span>
        </div>
        <h4 class="font-bold text-base mb-1">${les.title}</h4>
        <p class="text-xs text-slate-500 dark:text-slate-400 mb-3">${les.summary}</p>
        <div class="bg-slate-50 dark:bg-slate-900 p-3.5 rounded-lg text-xs font-mono text-slate-700 dark:text-slate-300 whitespace-pre-line border border-slate-200/80 dark:border-slate-800 mb-3">
${les.content}
        </div>
        ${les.interactiveTool ? `
          <button onclick="App.launchInteractiveTool('${les.interactiveTool}')" class="py-1.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-md shadow transition flex items-center gap-1.5">
            <span>Launch Interactive Simulator</span>
            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
          </button>
        ` : ''}
      </div>
    `).join('');

    this.openModal('modal-course-viewer');
  },

  launchInteractiveTool(toolKey) {
    this.closeModal('modal-course-viewer');
    const toolTitle = document.getElementById('tool-modal-title');
    const toolBody = document.getElementById('tool-modal-content');

    if (toolKey === 'quadratic-calc') {
      toolTitle.textContent = '⚡ Quadratic Equation Root Solver';
      toolBody.innerHTML = `
        <div class="space-y-4">
          <p class="text-sm text-slate-500">Equation Form: <b>ax² + bx + c = 0</b></p>
          <div class="grid grid-cols-3 gap-3">
            <div>
              <label class="text-xs font-bold block mb-1">Coeff 'a'</label>
              <input id="q-a" type="number" value="1" class="w-full p-2 border rounded dark:bg-slate-800 dark:border-slate-700">
            </div>
            <div>
              <label class="text-xs font-bold block mb-1">Coeff 'b'</label>
              <input id="q-b" type="number" value="-5" class="w-full p-2 border rounded dark:bg-slate-800 dark:border-slate-700">
            </div>
            <div>
              <label class="text-xs font-bold block mb-1">Coeff 'c'</label>
              <input id="q-c" type="number" value="6" class="w-full p-2 border rounded dark:bg-slate-800 dark:border-slate-700">
            </div>
          </div>
          <button onclick="App.calculateQuadratic()" class="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg transition">Compute Roots</button>
          <div id="q-result" class="p-3 bg-slate-100 dark:bg-slate-800 rounded text-sm font-mono text-center">Enter coefficients and click Compute</div>
        </div>
      `;
    } else if (toolKey === 'ohms-sim') {
      toolTitle.textContent = "⚡ Ohm's Law Circuit Calculator";
      toolBody.innerHTML = `
        <div class="space-y-4">
          <p class="text-sm text-slate-500">Formula: <b>V = I × R</b> (Voltage = Current × Resistance)</p>
          <div class="grid grid-cols-2 gap-3">
            <div>
              <label class="text-xs font-bold block mb-1">Current I (Amperes)</label>
              <input id="ohm-i" type="number" step="0.1" value="2.5" class="w-full p-2 border rounded dark:bg-slate-800 dark:border-slate-700">
            </div>
            <div>
              <label class="text-xs font-bold block mb-1">Resistance R (Ohms)</label>
              <input id="ohm-r" type="number" step="1" value="10" class="w-full p-2 border rounded dark:bg-slate-800 dark:border-slate-700">
            </div>
          </div>
          <button onclick="App.calculateOhms()" class="w-full py-2 bg-cyan-600 hover:bg-cyan-700 text-white font-bold rounded-lg transition">Calculate Potential Voltage</button>
          <div id="ohm-result" class="p-3 bg-slate-100 dark:bg-slate-800 rounded text-sm font-mono text-center">Result will appear here</div>
        </div>
      `;
    } else {
      toolTitle.textContent = "💻 Python & JavaScript Coding Sandbox";
      toolBody.innerHTML = `
        <div class="space-y-3">
          <p class="text-xs text-slate-500">Run code directly in your browser:</p>
          <textarea id="code-sandbox-input" rows="5" class="w-full p-3 font-mono text-xs border rounded-lg bg-slate-900 text-emerald-400">
// Interactive Algorithm Testing
let numbers = [12, 45, 78, 23, 89, 99];
let sum = numbers.reduce((a, b) => a + b, 0);
let avg = sum / numbers.length;
console.log("School Stall Interactive Data Lab");
console.log("Dataset: " + JSON.stringify(numbers));
console.log("Total Sum: " + sum);
console.log("Average: " + avg.toFixed(2));
          </textarea>
          <button onclick="App.runCodeSandbox()" class="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg transition">Run Code</button>
          <pre id="code-sandbox-output" class="p-3 bg-black text-green-400 font-mono text-xs rounded-lg min-h-[70px]">Output console will appear here...</pre>
        </div>
      `;
    }

    this.openModal('modal-interactive-tool');
  },

  calculateQuadratic() {
    const a = parseFloat(document.getElementById('q-a').value);
    const b = parseFloat(document.getElementById('q-b').value);
    const c = parseFloat(document.getElementById('q-c').value);
    const resEl = document.getElementById('q-result');

    if (isNaN(a) || isNaN(b) || isNaN(c) || a === 0) {
      resEl.textContent = "Error: 'a' must be a non-zero valid number!";
      return;
    }

    const D = (b * b) - (4 * a * c);
    if (D > 0) {
      const root1 = ((-b + Math.sqrt(D)) / (2 * a)).toFixed(3);
      const root2 = ((-b - Math.sqrt(D)) / (2 * a)).toFixed(3);
      resEl.innerHTML = `<span class="text-emerald-600 dark:text-emerald-400 font-bold">Discriminant D = ${D} > 0 (Two Real Roots):</span><br>Root 1 = <b>${root1}</b>, Root 2 = <b>${root2}</b>`;
    } else if (D === 0) {
      const root = (-b / (2 * a)).toFixed(3);
      resEl.innerHTML = `<span class="text-indigo-600 dark:text-indigo-400 font-bold">Discriminant D = 0 (Two Equal Roots):</span><br>Root = <b>${root}</b>`;
    } else {
      const real = (-b / (2 * a)).toFixed(3);
      const imag = (Math.sqrt(-D) / (2 * a)).toFixed(3);
      resEl.innerHTML = `<span class="text-amber-600 dark:text-amber-400 font-bold">Discriminant D = ${D} < 0 (Complex Roots):</span><br>x = <b>${real} ± ${imag}i</b>`;
    }
  },

  calculateOhms() {
    const i = parseFloat(document.getElementById('ohm-i').value);
    const r = parseFloat(document.getElementById('ohm-r').value);
    const resEl = document.getElementById('ohm-result');

    if (isNaN(i) || isNaN(r)) {
      resEl.textContent = "Please enter valid numeric values.";
      return;
    }

    const v = (i * r).toFixed(2);
    const p = (v * i).toFixed(2);
    resEl.innerHTML = `<span class="text-cyan-600 dark:text-cyan-400 font-bold">Potential Voltage V = ${v} Volts</span><br><span class="text-slate-500">Dissipated Power P = ${p} Watts</span>`;
  },

  runCodeSandbox() {
    const code = document.getElementById('code-sandbox-input').value;
    const outEl = document.getElementById('code-sandbox-output');
    outEl.textContent = "";

    const originalLog = console.log;
    let logs = [];
    console.log = (...args) => {
      logs.push(args.join(' '));
      originalLog.apply(console, args);
    };

    try {
      new Function(code)();
      outEl.textContent = logs.length ? logs.join('\n') : "Code executed successfully (no console output).";
    } catch (err) {
      outEl.textContent = "Execution Error: " + err.message;
    } finally {
      console.log = originalLog;
    }
  },

  async fetchResources() {
    try {
      const res = await fetch('/api/resources');
      if (res.ok) {
        const data = await res.json();
        this.loadedResources = data.resources || [];
        return this.loadedResources;
      }
    } catch (e) {
      console.warn("Could not fetch resources:", e);
    }
    this.loadedResources = [];
    return [];
  },

  async renderResources(filteredCategory = 'all') {
    const container = document.getElementById('resources-list-container');
    if (!container) return;

    if (!this.loadedResources) {
      container.innerHTML = `
        <div class="col-span-full py-12 text-center text-slate-400">
          <div class="text-3xl mb-2 animate-bounce">⏳</div>
          <p class="text-sm">Loading academic study materials...</p>
        </div>
      `;
      await this.fetchResources();
    }

    let list = this.loadedResources || [];
    if (filteredCategory !== 'all') {
      list = list.filter(r => (r.subject || '').toLowerCase().includes(filteredCategory.toLowerCase()));
    }

    if (list.length === 0) {
      container.innerHTML = `
        <div class="col-span-full glass-panel p-12 text-center border-dashed border-2 border-slate-300 dark:border-slate-700">
          <div class="text-4xl mb-3">📚</div>
          <h3 class="text-lg font-bold mb-1">No Downloadable PDF Materials Found</h3>
          <p class="text-xs text-slate-400 max-w-md mx-auto mb-4">
            ${filteredCategory !== 'all' ? `No resources currently available under "${filteredCategory}". Select "All" or check back later.` : 'School faculty and platform administrators can upload custom PDF question papers, notes, and formula sheets from the Admin Panel.'}
          </p>
          ${window.Auth && window.Auth.isAdmin() ? `
            <button onclick="App.switchTab('admin')" class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg text-xs transition">
              Open Admin Panel to Upload PDFs ↗
            </button>
          ` : ''}
        </div>
      `;
      return;
    }

    container.innerHTML = list.map(r => `
      <div class="glass-panel p-5 flex flex-col justify-between hover:border-indigo-400 transition">
        <div>
          <div class="flex items-center justify-between mb-2">
            <span class="badge-tag bg-cyan-100 text-cyan-800 dark:bg-cyan-950/60 dark:text-cyan-300">${r.badge || 'PDF'}</span>
            <span class="text-xs text-slate-400 font-mono">${r.fileSize || 'PDF'}</span>
          </div>
          <div class="flex items-start gap-3 mb-2">
            <span class="text-2xl flex-shrink-0">📄</span>
            <div>
              <h4 class="font-bold text-base leading-snug">${r.title}</h4>
              <p class="text-xs text-indigo-600 dark:text-indigo-400 font-semibold mt-0.5">${r.subject || 'General'}</p>
            </div>
          </div>
          <p class="text-xs text-slate-500 dark:text-slate-400 mb-4">${r.desc || 'Comprehensive downloadable academic resource for study and exam preparation.'}</p>
        </div>
        <div class="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800/80">
          <div class="flex items-center justify-between text-[11px] text-slate-400">
            <span class="truncate max-w-[150px] font-mono">${r.fileName || 'document.pdf'}</span>
            <span>${r.uploadedAt ? new Date(r.uploadedAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : 'Ready'}</span>
          </div>
          <a href="${r.fileUrl}" download="${r.fileName || 'Study_Material.pdf'}" target="_blank" onclick="App.trackDownload('${r.title}')" class="w-full py-2.5 px-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg text-xs transition flex items-center justify-center gap-2 shadow">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
            <span>Download PDF</span>
          </a>
        </div>
      </div>
    `).join('');
  },

  trackDownload(title) {
    this.showToast(`Downloading: ${title}...`);
  },

  renderDoneBy() {
    const authorEl = document.getElementById('doneby-author-container');
    if (!authorEl) return;

    const author = window.AppData ? window.AppData.author : {};
    const school = window.AppData ? window.AppData.school : {};

    authorEl.innerHTML = `
      <div class="glass-panel p-8 md:p-12 border-2 border-indigo-500/40 shadow-2xl relative overflow-hidden">
        <div class="flex flex-col md:flex-row items-center md:items-start gap-8">
          <div class="w-32 h-32 rounded-3xl bg-gradient-to-tr from-indigo-600 via-purple-600 to-cyan-400 flex items-center justify-center text-6xl shadow-2xl flex-shrink-0 text-white border-4 border-white/20">
            ${author.avatar || '🚀'}
          </div>
          <div class="space-y-4 text-center md:text-left flex-grow">
            <div>
              <div class="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-indigo-100 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 text-xs font-bold mb-2">
                <span>🌟</span><span>${author.badge}</span>
              </div>
              <h3 class="text-3xl sm:text-4xl font-extrabold tracking-tight">${author.name}</h3>
              <p class="text-sm sm:text-base font-semibold text-indigo-600 dark:text-indigo-400 mt-1">${author.title} • ${author.role}</p>
            </div>
            
            <p class="text-sm sm:text-base text-slate-600 dark:text-slate-300 leading-relaxed max-w-3xl">
              ${author.bio}
            </p>

            <blockquote class="italic text-xs sm:text-sm text-slate-500 dark:text-slate-400 border-l-4 border-indigo-500 pl-4 py-1.5 bg-slate-50 dark:bg-slate-900/40 rounded-r-lg">
              "${author.quote}"
            </blockquote>

            <div class="pt-2">
              <p class="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Core Engineering Competencies & Stack:</p>
              <div class="flex flex-wrap gap-2 justify-center md:justify-start">
                ${(author.skills || []).map(s => `
                  <span class="badge-tag bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 border border-slate-200 dark:border-slate-700 font-semibold">${s}</span>
                `).join('')}
              </div>
            </div>

            <div class="p-6 rounded-2xl bg-gradient-to-r from-indigo-50 to-cyan-50 dark:from-indigo-950/30 dark:to-cyan-950/20 border border-indigo-200/80 dark:border-indigo-800/50 mt-6">
              <div class="flex items-start gap-4">
                <span class="text-3xl">🙏</span>
                <div class="space-y-1">
                  <h5 class="font-bold text-sm text-indigo-950 dark:text-indigo-200">Personal Tribute & Alma Mater Dedication</h5>
                  <p class="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                    "This entire platform was created with immense gratitude to the esteemed management of <b>Theni Melapettai Hindu Nadargal Uravinmurai (TMHNU)</b>, our respected Principal <b>Mrs. N. Pooranaselvi</b>, our teachers, and mentors at <b>${school.name}</b>. Their encouragement and educational leadership inspired the creation of QuizGuider."
                  </p>
                  <p class="text-xs font-bold text-indigo-600 dark:text-indigo-400 pt-1">— ${author.name}</p>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    `;
  },

  renderOurSchool() {
    const container = document.getElementById('ourschool-container');
    if (!container) return;

    const school = window.AppData ? window.AppData.school : {};
    const admin = school.administration || {};

    container.innerHTML = `
      <div class="space-y-12">
        
        <!-- School Banner & Preamble Header -->
        <div class="glass-panel p-8 sm:p-12 border-2 border-indigo-500/30 shadow-2xl relative overflow-hidden shine-effect">
          <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-6 pb-6 border-b border-slate-200 dark:border-slate-800">
            <div>
              <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-100 dark:bg-cyan-950/60 text-cyan-800 dark:text-cyan-300 text-xs font-bold mb-2">
                <span>🏫</span><span>Alma Mater & Institutional Heritage</span>
              </div>
              <h2 class="text-2xl sm:text-4xl font-extrabold tracking-tight text-slate-900 dark:text-white leading-tight">
                ${school.name}
              </h2>
              <p class="text-xs sm:text-sm font-semibold text-indigo-600 dark:text-indigo-400 mt-1">
                Managed by: ${school.management}
              </p>
              <p class="text-xs text-slate-400 mt-0.5">
                Head Office: ${school.managementAddress}
              </p>
            </div>

            <div class="flex flex-wrap gap-2 self-start lg:self-center">
              <span class="badge-tag bg-blue-100 text-blue-800 dark:bg-blue-950/60 dark:text-blue-300">Est. ${school.established}</span>
              <span class="badge-tag bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300">2,000+ Scholars</span>
              <span class="badge-tag bg-purple-100 text-purple-800 dark:bg-purple-950/60 dark:text-purple-300">L.K.G to Std XII</span>
            </div>
          </div>

          <!-- School Motto Box -->
          <div class="mt-6 p-6 rounded-2xl bg-gradient-to-r from-amber-500/10 via-indigo-500/10 to-cyan-500/10 border border-amber-300/40 dark:border-amber-700/40">
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-2">
              <span class="text-xs font-black tracking-widest uppercase text-amber-600 dark:text-amber-400">Official School Motto</span>
              <span class="text-xs font-bold text-slate-500 font-mono">Edamal Street, Theni - 625531</span>
            </div>
            <h3 class="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mb-2">
              "${school.motto}"
            </h3>
            <p class="text-sm font-semibold text-indigo-900 dark:text-indigo-300 italic mb-2">
              "${school.mottoQuote}"
            </p>
            <p class="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              ${school.mottoExplanation}
            </p>
          </div>

          <!-- School Preamble Story -->
          <div class="mt-6 p-6 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800">
            <h4 class="font-bold text-base mb-2 flex items-center gap-2">
              <span>📜</span><span>School Preamble (From Official Diary)</span>
            </h4>
            <p class="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
              "${school.preamble}"
            </p>
          </div>

          <!-- Quick Contact strip -->
          <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-6 text-xs">
            <div class="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800/60">
              <span class="font-bold text-slate-400 block mb-0.5">Campus Venue</span>
              <p class="font-bold text-slate-800 dark:text-slate-200">${school.location}</p>
            </div>
            <div class="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800/60">
              <span class="font-bold text-slate-400 block mb-0.5">Telephone & Email</span>
              <p class="font-mono font-bold">${school.phone} • ${school.email}</p>
            </div>
            <div class="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800/60">
              <span class="font-bold text-slate-400 block mb-0.5">Official Website</span>
              <a href="${school.website}" target="_blank" class="text-indigo-600 dark:text-indigo-400 font-bold hover:underline">${school.website} ↗</a>
            </div>
          </div>
        </div>

        <!-- Academic Leadership & Principal's Desk -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div class="glass-panel p-6 sm:p-8 border-l-4 border-l-indigo-600 space-y-4">
            <div class="flex items-center gap-4">
              <div class="w-16 h-16 rounded-2xl bg-indigo-100 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300 flex items-center justify-center text-3xl font-bold shadow-md">
                👩‍🏫
              </div>
              <div>
                <span class="badge-tag bg-indigo-100 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300 mb-1">Academic Head</span>
                <h4 class="text-xl font-extrabold">${admin.principal ? admin.principal.name : 'Mrs. N. Pooranaselvi'}</h4>
                <p class="text-xs text-indigo-600 dark:text-indigo-400 font-mono font-bold">${admin.principal ? admin.principal.qualifications : 'M.A., B.Ed., (E) B.A., B.Ed., (H)'}</p>
                <p class="text-xs text-slate-400 font-bold">Principal, TMHNU Vidhyalaya Mat. Hr. Sec. School</p>
              </div>
            </div>
            <p class="text-xs text-slate-500 dark:text-slate-400 leading-relaxed border-t border-slate-100 dark:border-slate-800 pt-3">
              Providing holistic leadership, academic excellence, and disciplinary guidance to over 2000 young minds across kindergarten, primary, and higher secondary sections.
            </p>
          </div>

          <div class="glass-panel p-6 sm:p-8 border-l-4 border-l-cyan-500 space-y-4">
            <div class="flex items-center gap-4">
              <div class="w-16 h-16 rounded-2xl bg-cyan-100 text-cyan-700 dark:bg-cyan-950 dark:text-cyan-300 flex items-center justify-center text-3xl font-bold shadow-md">
                👩‍💼
              </div>
              <div>
                <span class="badge-tag bg-cyan-100 text-cyan-700 dark:bg-cyan-950 dark:text-cyan-300 mb-1">Vice-Principal</span>
                <h4 class="text-xl font-extrabold">${admin.vicePrincipal ? admin.vicePrincipal.name : 'Mrs. C. Sangeetha'}</h4>
                <p class="text-xs text-cyan-600 dark:text-cyan-400 font-mono font-bold">${admin.vicePrincipal ? admin.vicePrincipal.qualifications : 'M.A., B.Ed.'}</p>
                <p class="text-xs text-slate-400 font-bold">Vice-Principal, TMHNU Vidhyalaya Mat. Hr. Sec. School</p>
              </div>
            </div>
            <p class="text-xs text-slate-500 dark:text-slate-400 leading-relaxed border-t border-slate-100 dark:border-slate-800 pt-3">
              Steering curriculum standards, faculty development, co-curricular coordination, and student pastoral care with dedication.
            </p>
          </div>
        </div>

        <!-- Management Office Bearers -->
        <div class="glass-panel p-6 sm:p-8 space-y-6">
          <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200 dark:border-slate-800 pb-4">
            <div>
              <span class="badge-tag bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300 mb-1">TMHNU Governance</span>
              <h3 class="text-xl font-extrabold">Executive Office Bearers</h3>
            </div>
            <p class="text-xs text-slate-400">Theni Melapettai Hindu Nadargal Uravinmurai & Nadar Saraswathi Institutions</p>
          </div>

          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
            ${(admin.officeBearers || []).map(ob => `
              <div class="p-4 rounded-xl border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900/60 shadow-sm">
                <span class="text-[10px] font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400 block mb-1">${ob.role}</span>
                <p class="font-extrabold text-sm text-slate-800 dark:text-slate-200">${ob.name}</p>
              </div>
            `).join('')}
          </div>

          <!-- School Committees Roster -->
          <div class="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-slate-100 dark:border-slate-800">
            <div>
              <h4 class="font-bold text-sm mb-3 text-slate-700 dark:text-slate-300 flex items-center gap-2">
                <span>📋</span><span>Executive Committee Members</span>
              </h4>
              <div class="flex flex-wrap gap-2">
                ${(admin.executiveCommittee || []).map(m => `
                  <span class="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-[11px] font-semibold border border-slate-200 dark:border-slate-700">${m}</span>
                `).join('')}
              </div>
            </div>

            <div>
              <h4 class="font-bold text-sm mb-3 text-slate-700 dark:text-slate-300 flex items-center gap-2">
                <span>🏫</span><span>School Committee Members</span>
              </h4>
              <div class="flex flex-wrap gap-2">
                ${(admin.schoolCommittee || []).map(m => `
                  <span class="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-[11px] font-semibold border border-slate-200 dark:border-slate-700">${m}</span>
                `).join('')}
              </div>
            </div>
          </div>
        </div>

        <!-- Academic Structure, Timings & Terms -->
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          <!-- Curriculum -->
          <div class="glass-panel p-6 space-y-4">
            <h4 class="font-bold text-base flex items-center gap-2">
              <span>📚</span><span>Curriculum of Studies</span>
            </h4>
            <div class="space-y-3 text-xs">
              ${(school.curriculum || []).map(c => `
                <div class="p-3.5 rounded-xl border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900/60">
                  <p class="font-bold text-indigo-600 dark:text-indigo-400 mb-1">${c.level}</p>
                  <p class="text-slate-600 dark:text-slate-300 leading-relaxed">${c.details}</p>
                </div>
              `).join('')}
            </div>
          </div>

          <!-- School Working Hours -->
          <div class="glass-panel p-6 space-y-4">
            <h4 class="font-bold text-base flex items-center gap-2">
              <span>⏰</span><span>School Working Hours</span>
            </h4>
            <div class="space-y-3 text-xs">
              ${(school.timings || []).map(t => `
                <div class="p-3.5 rounded-xl border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900/60 flex items-center justify-between">
                  <span class="font-bold text-slate-700 dark:text-slate-300">${t.section}</span>
                  <span class="font-mono font-bold text-indigo-600 dark:text-indigo-400">${t.hours}</span>
                </div>
              `).join('')}
            </div>
          </div>

          <!-- Academic Terms -->
          <div class="glass-panel p-6 space-y-4">
            <h4 class="font-bold text-base flex items-center gap-2">
              <span>📅</span><span>Academic Terms</span>
            </h4>
            <div class="space-y-3 text-xs">
              ${(school.terms || []).map(tm => `
                <div class="p-3.5 rounded-xl border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900/60 flex items-center justify-between">
                  <span class="font-bold text-slate-700 dark:text-slate-300">${tm.term}</span>
                  <span class="badge-tag bg-cyan-100 text-cyan-800 dark:bg-cyan-950 dark:text-cyan-300">${tm.duration}</span>
                </div>
              `).join('')}
            </div>
          </div>

        </div>

        <!-- Campus Facilities & Infrastructure -->
        <div class="space-y-6">
          <div>
            <span class="badge-tag bg-indigo-100 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300 mb-2">Campus Highlights</span>
            <h3 class="text-2xl font-extrabold tracking-tight">World-Class Academic Infrastructure</h3>
            <p class="text-xs text-slate-500">Documented from the official school diary and inspection archives.</p>
          </div>

          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            ${(school.infrastructure || []).map(inf => `
              <div class="glass-panel p-6 flex flex-col justify-between hover:border-indigo-400 transition-all duration-300 group">
                <div>
                  <span class="text-3xl block mb-3 group-hover:scale-110 transition-transform">${inf.icon}</span>
                  <h4 class="font-bold text-base mb-2">${inf.title}</h4>
                  <p class="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">${inf.desc}</p>
                </div>
              </div>
            `).join('')}
          </div>
        </div>

        <!-- Code of Conduct & Rules -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
          <!-- Student Rules -->
          <div class="glass-panel p-6 sm:p-8 space-y-4">
            <div class="flex items-center gap-2 mb-2">
              <span class="text-2xl">🎓</span>
              <div>
                <h4 class="font-bold text-lg">Rules & Regulations: To Students</h4>
                <p class="text-[11px] text-slate-400">Pages 32 & 33 of School Diary</p>
              </div>
            </div>
            <ul class="space-y-2.5 text-xs text-slate-600 dark:text-slate-300">
              ${((school.rules && school.rules.students) || []).map(r => `
                <li class="flex items-start gap-2.5">
                  <span class="text-indigo-600 dark:text-indigo-400 font-bold text-sm">✓</span>
                  <span class="leading-relaxed">${r}</span>
                </li>
              `).join('')}
            </ul>
          </div>

          <!-- Parent Instructions -->
          <div class="glass-panel p-6 sm:p-8 space-y-4">
            <div class="flex items-center gap-2 mb-2">
              <span class="text-2xl">👨‍👩‍👧‍👦</span>
              <div>
                <h4 class="font-bold text-lg">Guidelines: To Parents</h4>
                <p class="text-[11px] text-slate-400">Pages 33 & 34 of School Diary</p>
              </div>
            </div>
            <ul class="space-y-2.5 text-xs text-slate-600 dark:text-slate-300">
              ${((school.rules && school.rules.parents) || []).map(r => `
                <li class="flex items-start gap-2.5">
                  <span class="text-cyan-600 dark:text-cyan-400 font-bold text-sm">✓</span>
                  <span class="leading-relaxed">${r}</span>
                </li>
              `).join('')}
            </ul>
          </div>
        </div>

      </div>
    `;
  },

  openModal(modalId) {
    const el = document.getElementById(modalId);
    if (el) {
      el.classList.remove('hidden');
      document.body.style.overflow = 'hidden';
    }
  },

  closeModal(modalId) {
    const el = document.getElementById(modalId);
    if (el) {
      el.classList.add('hidden');
      document.body.style.overflow = 'auto';
    }
  },

  showToast(message, type = 'success') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = 'toast-item';
    const icon = type === 'error' ? '❌' : (type === 'info' ? 'ℹ️' : '✅');
    toast.innerHTML = `<span>${icon}</span><span class="text-sm font-medium">${message}</span>`;

    container.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(10px)';
      toast.style.transition = 'all 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 3500);
  },

  triggerConfetti() {
    const canvas = document.getElementById('confetti-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    canvas.classList.remove('hidden');

    const particles = [];
    const colors = ['#4f46e5', '#06b6d4', '#10b981', '#f59e0b', '#ec4899', '#8b5cf6'];

    for (let i = 0; i < 120; i++) {
      particles.push({
        x: canvas.width / 2,
        y: canvas.height / 2,
        r: Math.random() * 6 + 2,
        dx: (Math.random() - 0.5) * 16,
        dy: (Math.random() - 0.5) * 16 - 4,
        color: colors[Math.floor(Math.random() * colors.length)],
        tilt: Math.random() * 10,
        tiltAngleIncremental: (Math.random() * 0.07) + 0.05,
        tiltAngle: 0
      });
    }

    let animationFrames = 0;
    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      particles.forEach(p => {
        p.tiltAngle += p.tiltAngleIncremental;
        p.y += (Math.cos(p.tiltAngle) + 1 + p.r / 2) / 2;
        p.x += Math.sin(p.tiltAngle) * 2;
        p.x += p.dx * 0.95;
        p.y += p.dy * 0.95;
        p.dy += 0.15;

        ctx.beginPath();
        ctx.lineWidth = p.r / 2;
        ctx.strokeStyle = p.color;
        ctx.moveTo(p.x + p.tilt + (p.r / 4), p.y);
        ctx.lineTo(p.x + p.tilt, p.y + p.tilt + (p.r / 4));
        ctx.stroke();
      });

      animationFrames++;
      if (animationFrames < 160) {
        requestAnimationFrame(render);
      } else {
        canvas.classList.add('hidden');
      }
    };

    render();
  }
};

window.App = App;

document.addEventListener('DOMContentLoaded', () => {
  App.init();
});
