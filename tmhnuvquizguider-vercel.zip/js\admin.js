/**
 * Admin Portal Management
 * Elevated controls for Platform Administrators:
 * 1. Overview analytics (Students count, Quiz activity, Announcements)
 * 2. Create, Edit, & Delete Assessments & Questions
 * 3. Publish School & Platform Announcements
 * 4. Monitor registered users and their unique databases
 * 5. One-click Cloud Database Sync
 */

const AdminPortal = {
  init() {
    this.renderAdminDashboard();
  },

  checkAccess() {
    return window.Auth && window.Auth.isAdmin();
  },

  renderAdminDashboard() {
    const container = document.getElementById('admin-content-view');
    if (!container) return;

    if (!this.checkAccess()) {
      container.innerHTML = `
        <div class="glass-panel p-12 text-center max-w-lg mx-auto">
          <div class="w-16 h-16 bg-rose-100 dark:bg-rose-950/50 text-rose-600 rounded-full flex items-center justify-center mx-auto mb-4 text-3xl">
            🔒
          </div>
          <h2 class="text-2xl font-bold mb-2">Restricted Administrator Area</h2>
          <p class="text-slate-500 text-sm mb-6">You must be logged in with an authorized Administrator account to access management tools.</p>
          <button onclick="window.App.openModal('modal-admin-login')" class="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg shadow transition">
            Open Admin Login
          </button>
        </div>
      `;
      return;
    }

    if (!document.getElementById('admin-stat-students')) {
      container.innerHTML = `
        <div class="space-y-8">
          <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <span class="badge-tag bg-indigo-100 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300 mb-2">🛡️ Elevated Administration</span>
              <h2 class="text-3xl font-extrabold tracking-tight">Faculty & Systems Control</h2>
              <p class="text-slate-500 dark:text-slate-400 text-sm">Real-time telemetry, isolated student partitions, PDF uploads, and instant cloud sync.</p>
            </div>
            <div class="flex items-center gap-3">
              <button onclick="AdminPortal.syncToCloud()" class="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-xl shadow-lg transition flex items-center gap-2 text-sm">
                <span>☁️ One-Click Cloud Sync</span>
              </button>
            </div>
          </div>

          <!-- Overview Stats -->
          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <div class="glass-panel p-6 border-l-4 border-l-indigo-600">
              <span class="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">Active Scholars</span>
              <div id="admin-stat-students" class="text-3xl font-extrabold text-indigo-600 dark:text-indigo-400">0</div>
              <p class="text-xs text-slate-400 mt-1">Unique JSON databases</p>
            </div>
            <div class="glass-panel p-6 border-l-4 border-l-cyan-500">
              <span class="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">Assessment Modules</span>
              <div id="admin-stat-quizzes" class="text-3xl font-extrabold text-cyan-600 dark:text-cyan-400">0</div>
              <p class="text-xs text-slate-400 mt-1">Standard & custom quizzes</p>
            </div>
            <div class="glass-panel p-6 border-l-4 border-l-amber-500">
              <span class="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">Active Notices</span>
              <div id="admin-stat-announcements" class="text-3xl font-extrabold text-amber-600 dark:text-amber-400">0</div>
              <p class="text-xs text-slate-400 mt-1">Published announcements</p>
            </div>
            <div class="glass-panel p-6 border-l-4 border-l-emerald-500">
              <span class="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">Custom PDF Files</span>
              <div id="admin-stat-resources" class="text-3xl font-extrabold text-emerald-600 dark:text-emerald-400">0</div>
              <p class="text-xs text-slate-400 mt-1">Uploaded study materials</p>
            </div>
          </div>

          <!-- PDF Study Material & Resource Manager -->
          <div class="glass-panel p-6 border border-emerald-500/30">
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
              <div>
                <span class="badge-tag bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300 mb-1">📁 Academic Repository</span>
                <h3 class="text-xl font-bold flex items-center gap-2">
                  <span>📄</span><span>Custom PDF Study Materials & Resources</span>
                </h3>
                <p class="text-xs text-slate-400">Upload your own school PDFs (Question papers, Guides, Formula sheets). Students can download them directly from the Resources tab.</p>
              </div>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <!-- Upload Form -->
              <div class="lg:col-span-1 p-5 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800">
                <h4 class="font-bold text-sm mb-4 flex items-center gap-2 text-indigo-600 dark:text-indigo-400">
                  <span>📤</span><span>Upload New PDF Document</span>
                </h4>
                <form id="admin-pdf-upload-form" onsubmit="event.preventDefault(); AdminPortal.handlePdfUploadForm();" class="space-y-4 text-xs">
                  <div>
                    <label class="block font-bold text-slate-700 dark:text-slate-300 mb-1">Document Title *</label>
                    <input id="admin-pdf-title" type="text" required placeholder="e.g. 10th Standard Science Model Question Paper" class="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:ring-2 focus:ring-indigo-500">
                  </div>
                  <div>
                    <label class="block font-bold text-slate-700 dark:text-slate-300 mb-1">Subject / Stream *</label>
                    <select id="admin-pdf-subject" required class="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:ring-2 focus:ring-indigo-500">
                      <option value="Mathematics">Mathematics</option>
                      <option value="Physics">Physics</option>
                      <option value="Chemistry">Chemistry</option>
                      <option value="Biology">Biology</option>
                      <option value="Computer Science">Computer Science</option>
                      <option value="English">English</option>
                      <option value="Tamil">Tamil</option>
                      <option value="Social Science">Social Science</option>
                      <option value="General STEM">General STEM</option>
                    </select>
                  </div>
                  <div>
                    <label class="block font-bold text-slate-700 dark:text-slate-300 mb-1">Category Badge</label>
                    <input id="admin-pdf-badge" type="text" placeholder="e.g. Question Bank, Formula Sheet, Notes" class="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:ring-2 focus:ring-indigo-500" value="Study Material">
                  </div>
                  <div>
                    <label class="block font-bold text-slate-700 dark:text-slate-300 mb-1">Brief Description</label>
                    <textarea id="admin-pdf-desc" rows="2" placeholder="Explain what students will find in this PDF..." class="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:ring-2 focus:ring-indigo-500"></textarea>
                  </div>
                  <div>
                    <label class="block font-bold text-slate-700 dark:text-slate-300 mb-1">Select PDF File (.pdf) *</label>
                    <div class="border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-indigo-500 rounded-xl p-4 text-center cursor-pointer bg-white dark:bg-slate-800/50 transition" onclick="document.getElementById('admin-pdf-file-input').click()">
                      <input id="admin-pdf-file-input" type="file" accept=".pdf,application/pdf" required class="hidden" onchange="AdminPortal.handleFileSelected(this)">
                      <div class="text-2xl mb-1">📄</div>
                      <p id="admin-pdf-file-label" class="font-bold text-xs text-slate-600 dark:text-slate-300">Click to choose PDF file</p>
                      <p class="text-[10px] text-slate-400 mt-0.5">Maximum file size: 50MB</p>
                    </div>
                  </div>
                  <button id="admin-pdf-upload-btn" type="submit" class="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg shadow transition flex items-center justify-center gap-2">
                    <span>⬆️ Upload PDF Resource</span>
                  </button>
                </form>
              </div>

              <!-- Live Uploaded PDF List -->
              <div class="lg:col-span-2">
                <div class="flex items-center justify-between mb-3">
                  <h4 class="font-bold text-sm text-slate-700 dark:text-slate-300">
                    Uploaded PDF Library (<span id="admin-resources-count">0</span>)
                  </h4>
                  <button onclick="AdminPortal.refreshResources()" class="text-xs text-indigo-600 hover:underline flex items-center gap-1 font-semibold">
                    <span>🔄 Refresh</span>
                  </button>
                </div>
                <div id="admin-resources-list" class="space-y-3 max-h-[480px] overflow-y-auto pr-2">
                  <!-- Populated by AdminPortal.renderResourcesManager() -->
                </div>
              </div>
            </div>
          </div>

          <!-- Announcements Manager -->
          <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div class="lg:col-span-1 glass-panel p-6">
              <h3 class="text-lg font-bold mb-4 flex items-center gap-2">
                <span>📢</span><span>Publish Announcement</span>
              </h3>
              <form id="admin-ann-form" onsubmit="event.preventDefault(); AdminPortal.createAnnouncement(document.getElementById('admin-ann-title').value, document.getElementById('admin-ann-tag').value, document.getElementById('admin-ann-content').value, document.getElementById('admin-ann-pinned').checked); document.getElementById('admin-ann-form').reset();" class="space-y-4 text-xs">
                <div>
                  <label class="block font-bold text-slate-700 dark:text-slate-300 mb-1">Notice Title</label>
                  <input id="admin-ann-title" type="text" required placeholder="e.g. Science Exhibition Stall Briefing" class="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:ring-2 focus:ring-indigo-500">
                </div>
                <div>
                  <label class="block font-bold text-slate-700 dark:text-slate-300 mb-1">Category / Tag</label>
                  <input id="admin-ann-tag" type="text" placeholder="Academic / Event / STEM" class="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:ring-2 focus:ring-indigo-500">
                </div>
                <div>
                  <label class="block font-bold text-slate-700 dark:text-slate-300 mb-1">Notice Description</label>
                  <textarea id="admin-ann-content" required rows="3" placeholder="Provide full briefing details..." class="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:ring-2 focus:ring-indigo-500"></textarea>
                </div>
                <div class="flex items-center gap-2">
                  <input id="admin-ann-pinned" type="checkbox" class="rounded text-indigo-600 focus:ring-indigo-500">
                  <label for="admin-ann-pinned" class="font-bold text-slate-600 dark:text-slate-300">Pin to top of bulletin</label>
                </div>
                <button type="submit" class="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg shadow transition">
                  Publish Notice
                </button>
              </form>
            </div>

            <div class="lg:col-span-2 glass-panel p-6">
              <h3 class="text-lg font-bold mb-4 flex items-center justify-between">
                <span class="flex items-center gap-2"><span>📋</span><span>Live Announcements List</span></span>
              </h3>
              <div id="admin-announcements-list" class="space-y-3 max-h-96 overflow-y-auto pr-2"></div>
            </div>
          </div>

          <!-- Quizzes Manager -->
          <div class="glass-panel p-6">
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
              <div>
                <h3 class="text-lg font-bold flex items-center gap-2">
                  <span>📝</span><span>Curriculum Assessments & Challenges</span>
                </h3>
                <p class="text-xs text-slate-400">All standard system and faculty-authored assessments</p>
              </div>
              <button onclick="window.App.openModal('modal-create-quiz')" class="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg text-xs shadow transition flex items-center gap-1.5">
                <span>➕ Create New Assessment</span>
              </button>
            </div>
            <div id="admin-quizzes-list" class="grid grid-cols-1 md:grid-cols-2 gap-4"></div>
          </div>

          <!-- Registered Students & User Databases Telemetry -->
          <div class="glass-panel p-6">
            <h3 class="text-lg font-bold mb-2 flex items-center gap-2">
              <span>🗄️</span><span>Isolated User Database Partitions</span>
            </h3>
            <p class="text-xs text-slate-400 mb-4">Every user registered on QuizGuider receives a standalone partition file stored in <code class="bg-slate-100 dark:bg-slate-800 px-1 py-0.5 rounded">data/user_databases/user_&lt;id&gt;.json</code>.</p>
            <div class="overflow-x-auto">
              <table class="w-full text-left border-collapse">
                <thead>
                  <tr class="border-b border-slate-200 dark:border-slate-800 text-xs font-bold text-slate-400 uppercase tracking-wider">
                    <th class="py-3 px-4">Student Scholar</th>
                    <th class="py-3 px-4">Database UUID</th>
                    <th class="py-3 px-4">Partition Status</th>
                    <th class="py-3 px-4">Live Score</th>
                    <th class="py-3 px-4">Academic Division</th>
                  </tr>
                </thead>
                <tbody id="admin-students-list"></tbody>
              </table>
            </div>
          </div>
        </div>
      `;
    }

    this.renderStats();
    this.renderResourcesManager();
    this.renderAnnouncementsManager();
    this.renderQuizzesManager();
    this.renderStudentsManager();
  },

  async renderStats() {
    const quizzes = window.QuizEngine.getAllQuizzes();
    const announcements = this.getAnnouncements();

    let studentCount = 0;
    try {
      const res = await fetch('/api/leaderboard');
      if (res.ok) {
        const data = await res.json();
        studentCount = data.totalTrackedScholars || 0;
      }
    } catch (e) {
      studentCount = 1;
    }

    let resourceCount = 0;
    try {
      const rRes = await fetch('/api/resources');
      if (rRes.ok) {
        const rData = await rRes.json();
        resourceCount = (rData.resources || []).length;
      }
    } catch (e) {}

    const totalStudentsEl = document.getElementById('admin-stat-students');
    const totalQuizzesEl = document.getElementById('admin-stat-quizzes');
    const totalAnnouncementsEl = document.getElementById('admin-stat-announcements');
    const totalResourcesEl = document.getElementById('admin-stat-resources');

    if (totalStudentsEl) totalStudentsEl.textContent = studentCount;
    if (totalQuizzesEl) totalQuizzesEl.textContent = quizzes.length;
    if (totalAnnouncementsEl) totalAnnouncementsEl.textContent = announcements.length;
    if (totalResourcesEl) totalResourcesEl.textContent = resourceCount;
  },

  getAnnouncements() {
    const custom = JSON.parse(localStorage.getItem('edunova_custom_announcements') || '[]');
    return [...(window.AppData ? window.AppData.announcements : []), ...custom];
  },

  renderAnnouncementsManager() {
    const listEl = document.getElementById('admin-announcements-list');
    if (!listEl) return;

    const announcements = this.getAnnouncements();
    listEl.innerHTML = announcements.map(ann => `
      <div class="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800/60 flex items-start justify-between gap-4">
        <div>
          <div class="flex items-center gap-2 mb-1">
            <span class="badge-tag bg-indigo-100 text-indigo-700 dark:bg-indigo-900/50 dark:text-indigo-300">${ann.tag}</span>
            <span class="text-xs text-slate-400">${ann.date}</span>
            ${ann.pinned ? '<span class="text-xs font-bold text-amber-500">📌 Pinned</span>' : ''}
          </div>
          <h4 class="font-bold text-base mb-1">${ann.title}</h4>
          <p class="text-xs text-slate-500 dark:text-slate-400">${ann.content}</p>
        </div>
        <button onclick="AdminPortal.deleteAnnouncement('${ann.id}')" class="text-xs text-rose-600 hover:text-rose-700 font-bold p-1 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded transition">
          Delete
        </button>
      </div>
    `).join('');
  },

  createAnnouncement(title, tag, content, isPinned) {
    if (!title || !content) {
      window.App.showToast("Please provide both title and content", "error");
      return;
    }

    const custom = JSON.parse(localStorage.getItem('edunova_custom_announcements') || '[]');
    const newAnn = {
      id: 'ann_' + Date.now(),
      title: title.trim(),
      tag: tag || 'General',
      content: content.trim(),
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      pinned: !!isPinned
    };

    custom.unshift(newAnn);
    localStorage.setItem('edunova_custom_announcements', JSON.stringify(custom));
    window.App.showToast("Announcement published successfully!");
    this.renderAnnouncementsManager();
    this.renderStats();
    if (window.App) window.App.renderAnnouncements();
  },

  deleteAnnouncement(id) {
    let custom = JSON.parse(localStorage.getItem('edunova_custom_announcements') || '[]');
    custom = custom.filter(a => a.id !== id);
    localStorage.setItem('edunova_custom_announcements', JSON.stringify(custom));
    window.App.showToast("Announcement removed.");
    this.renderAnnouncementsManager();
    this.renderStats();
    if (window.App) window.App.renderAnnouncements();
  },

  renderQuizzesManager() {
    const listEl = document.getElementById('admin-quizzes-list');
    if (!listEl) return;

    const quizzes = window.QuizEngine.getAllQuizzes();
    listEl.innerHTML = quizzes.map(q => `
      <div class="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800/60 flex items-center justify-between">
        <div>
          <span class="badge-tag bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300 mb-1">${q.category}</span>
          <h4 class="font-bold text-sm">${q.title}</h4>
          <p class="text-xs text-slate-400">${q.questions.length} Questions | ${q.timeLimitMinutes} min limit | Passing: ${q.passingScore}%</p>
        </div>
        ${q.id.startsWith('quiz-custom') ? `
          <button onclick="AdminPortal.deleteCustomQuiz('${q.id}')" class="text-xs text-rose-600 hover:text-rose-700 font-bold p-1 hover:bg-rose-50 rounded">
            Delete
          </button>
        ` : '<span class="text-xs text-slate-400 font-mono">System Standard</span>'}
      </div>
    `).join('');
  },

  createQuiz(title, category, timeMinutes, passingScore, questions) {
    if (!title || !questions.length) {
      window.App.showToast("Please provide quiz title and at least 1 question", "error");
      return;
    }

    const custom = JSON.parse(localStorage.getItem('edunova_custom_quizzes') || '[]');
    const newQuiz = {
      id: 'quiz-custom-' + Date.now(),
      title: title.trim(),
      category: category || "STEM Practice",
      difficulty: "Custom",
      timeLimitMinutes: parseInt(timeMinutes, 10) || 10,
      passingScore: parseInt(passingScore, 10) || 70,
      description: `Custom assessment module created by faculty.`,
      questions: questions
    };

    custom.unshift(newQuiz);
    localStorage.setItem('edunova_custom_quizzes', JSON.stringify(custom));
    window.App.showToast("New quiz assessment created and published!");
    this.renderQuizzesManager();
    this.renderStats();
    window.QuizEngine.renderQuizList();
  },

  deleteCustomQuiz(quizId) {
    let custom = JSON.parse(localStorage.getItem('edunova_custom_quizzes') || '[]');
    custom = custom.filter(q => q.id !== quizId);
    localStorage.setItem('edunova_custom_quizzes', JSON.stringify(custom));
    window.App.showToast("Quiz removed.");
    this.renderQuizzesManager();
    this.renderStats();
    window.QuizEngine.renderQuizList();
  },

  async renderStudentsManager() {
    const listEl = document.getElementById('admin-students-list');
    if (!listEl) return;

    let scholars = [];
    try {
      const res = await fetch('/api/leaderboard');
      if (res.ok) {
        const data = await res.json();
        scholars = data.honorRoll || [];
      }
    } catch (e) {}

    const currentUser = window.Auth.getCurrentUser();
    if (!scholars.length && currentUser && currentUser.role !== 'admin') {
      scholars = [currentUser];
    }

    if (!scholars.length) {
      listEl.innerHTML = `<tr><td colspan="5" class="text-sm text-slate-400 py-6 text-center">No live student scores recorded yet. When students complete assessments, their unique database telemetry appears here in real time.</td></tr>`;
      return;
    }

    listEl.innerHTML = scholars.map(u => `
      <tr class="border-b border-slate-100 dark:border-slate-800 text-xs">
        <td class="py-3 px-4 font-semibold flex items-center gap-2">
          <span>${u.avatar || '🎓'}</span>
          <span>${u.name}</span>
        </td>
        <td class="py-3 px-4 text-slate-500 font-mono">${u.userId || u.id || 'Live User'}</td>
        <td class="py-3 px-4">
          <span class="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300">
            Isolated DB Partition
          </span>
        </td>
        <td class="py-3 px-4 font-bold text-indigo-600 dark:text-indigo-400">${u.score || (u.stats ? u.stats.points : 0)} pts</td>
        <td class="py-3 px-4 text-slate-400">${u.grade || 'Student'}</td>
      </tr>
    `).join('');
  },

  async syncToCloud() {
    window.App.showToast("Syncing all isolated user databases to cloud storage...", "info");
    try {
      const res = await fetch('/api/cloud/sync', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        window.App.showToast(`☁️ Cloud Sync Completed! ${data.syncedDatabases} unique user databases synchronized.`);
      } else {
        window.App.showToast(data.error || "Sync failed", "error");
      }
    } catch (err) {
      window.App.showToast("Cloud synchronization completed locally.", "info");
    }
  },

  handleFileSelected(input) {
    if (input.files && input.files[0]) {
      const file = input.files[0];
      const label = document.getElementById('admin-pdf-file-label');
      const sizeStr = file.size < 1024 * 1024
        ? `${(file.size / 1024).toFixed(1)} KB`
        : `${(file.size / (1024 * 1024)).toFixed(2)} MB`;
      if (label) {
        label.innerHTML = `<b>Selected:</b> ${file.name} (${sizeStr})`;
      }
      const titleInput = document.getElementById('admin-pdf-title');
      if (titleInput && !titleInput.value) {
        titleInput.value = file.name.replace(/\.[^/.]+$/, "").replace(/[-_]/g, " ");
      }
    }
  },

  async handlePdfUploadForm() {
    const title = (document.getElementById('admin-pdf-title')?.value || '').trim();
    const subject = document.getElementById('admin-pdf-subject')?.value || 'General';
    const badge = (document.getElementById('admin-pdf-badge')?.value || 'Study Material').trim();
    const desc = (document.getElementById('admin-pdf-desc')?.value || '').trim();
    const fileInput = document.getElementById('admin-pdf-file-input');
    const btn = document.getElementById('admin-pdf-upload-btn');

    if (!title) {
      window.App.showToast("Please provide a title for the document.", "error");
      return;
    }
    if (!fileInput || !fileInput.files || !fileInput.files[0]) {
      window.App.showToast("Please choose a PDF file to upload.", "error");
      return;
    }

    const file = fileInput.files[0];
    if (!file.name.toLowerCase().endsWith('.pdf') && file.type !== 'application/pdf') {
      window.App.showToast("Only PDF files are supported.", "error");
      return;
    }

    if (file.size > 50 * 1024 * 1024) {
      window.App.showToast("File size exceeds 50MB limit.", "error");
      return;
    }

    if (btn) {
      btn.disabled = true;
      btn.innerHTML = `<span class="animate-spin">⏳</span><span>Uploading PDF...</span>`;
    }

    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const base64Data = reader.result;
        const res = await fetch('/api/resources/upload', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            title,
            subject,
            badge,
            desc,
            fileName: file.name,
            fileData: base64Data
          })
        });

        const data = await res.json();
        if (data.success) {
          window.App.showToast("✅ PDF Document uploaded successfully!");
          document.getElementById('admin-pdf-upload-form').reset();
          const label = document.getElementById('admin-pdf-file-label');
          if (label) label.textContent = "Click to choose PDF file";
          
          // Hybrid backup for Vercel Serverless
          try {
            let localList = JSON.parse(localStorage.getItem('quizguider_custom_resources') || '[]');
            const uploadedItem = data.resource || {
              id: 'res_' + Date.now(),
              title,
              subject,
              badge,
              desc,
              fileName: file.name,
              fileSize: `${Math.round(file.size / 1024)} KB`,
              fileUrl: base64Data,
              uploadedAt: new Date().toISOString()
            };
            localList = [uploadedItem, ...localList.filter(r => r.id !== uploadedItem.id)];
            localStorage.setItem('quizguider_custom_resources', JSON.stringify(localList));
          } catch (storageErr) {
            console.warn("Storage quota note:", storageErr);
          }

          await this.renderResourcesManager();
          this.renderStats();
          if (window.App) {
            await window.App.fetchResources();
            window.App.renderResources();
          }
        } else {
          window.App.showToast(data.error || "Upload failed", "error");
        }
      } catch (err) {
        window.App.showToast("Error uploading file: " + err.message, "error");
      } finally {
        if (btn) {
          btn.disabled = false;
          btn.innerHTML = `<span>⬆️ Upload PDF Resource</span>`;
        }
      }
    };
    reader.onerror = () => {
      window.App.showToast("Error reading file", "error");
      if (btn) {
        btn.disabled = false;
        btn.innerHTML = `<span>⬆️ Upload PDF Resource</span>`;
      }
    };
    reader.readAsDataURL(file);
  },

  async renderResourcesManager() {
    const listEl = document.getElementById('admin-resources-list');
    const countEl = document.getElementById('admin-resources-count');
    if (!listEl) return;

    let apiResources = [];
    try {
      const res = await fetch('/api/resources');
      if (res.ok) {
        const data = await res.json();
        apiResources = data.resources || [];
      }
    } catch (e) {
      console.warn("Could not load resources from API:", e);
    }

    const localResources = JSON.parse(localStorage.getItem('quizguider_custom_resources') || '[]');
    const mergedMap = new Map();
    for (const r of [...apiResources, ...localResources]) {
      if (r && r.id && !mergedMap.has(r.id)) {
        mergedMap.set(r.id, r);
      }
    }
    const resources = Array.from(mergedMap.values());

    if (countEl) countEl.textContent = resources.length;

    if (resources.length === 0) {
      listEl.innerHTML = `
        <div class="p-8 text-center border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-xl text-slate-400">
          <div class="text-3xl mb-2">📂</div>
          <p class="font-bold text-xs mb-1">No Custom PDF Resources Yet</p>
          <p class="text-[11px]">Upload custom PDFs using the form on the left. All uploaded PDFs will instantly appear here and in the public Resources tab.</p>
        </div>
      `;
      return;
    }

    listEl.innerHTML = resources.map(r => `
      <div class="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800/60 flex items-start justify-between gap-4 hover:border-indigo-300 transition">
        <div class="flex items-start gap-3 min-w-0 flex-grow">
          <div class="w-10 h-10 rounded-lg bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 flex items-center justify-center text-xl flex-shrink-0">
            📄
          </div>
          <div class="min-w-0 flex-grow">
            <div class="flex items-center gap-2 mb-1 flex-wrap">
              <span class="badge-tag bg-cyan-100 text-cyan-800 dark:bg-cyan-950/60 dark:text-cyan-300 text-[10px]">${r.badge || 'PDF'}</span>
              <span class="badge-tag bg-indigo-100 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300 text-[10px]">${r.subject || 'General'}</span>
              <span class="text-xs text-slate-400 font-mono">${r.fileSize || ''}</span>
            </div>
            <h4 class="font-bold text-sm truncate mb-0.5 text-slate-800 dark:text-slate-200">${r.title}</h4>
            <p class="text-xs text-slate-400 truncate mb-1 font-mono">${r.fileName}</p>
            ${r.desc ? `<p class="text-xs text-slate-500 dark:text-slate-400 line-clamp-2">${r.desc}</p>` : ''}
          </div>
        </div>
        <div class="flex flex-col items-end gap-2 flex-shrink-0">
          <a href="${r.fileUrl}" download="${r.fileName}" target="_blank" class="px-2.5 py-1.5 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-300 hover:bg-indigo-100 text-xs font-bold transition flex items-center gap-1">
            <span>Download</span>
          </a>
          <button onclick="AdminPortal.deleteResource('${r.id}')" class="text-xs text-rose-600 hover:text-rose-700 font-bold p-1 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded transition">
            Delete
          </button>
        </div>
      </div>
    `).join('');
  },

  async deleteResource(id) {
    if (!confirm("Are you sure you want to delete this PDF resource?")) return;

    // Remove from local backup
    let localResources = JSON.parse(localStorage.getItem('quizguider_custom_resources') || '[]');
    localResources = localResources.filter(r => r.id !== id);
    localStorage.setItem('quizguider_custom_resources', JSON.stringify(localResources));

    try {
      const res = await fetch('/api/resources/delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id })
      });
      await res.json();
    } catch (e) {}

    window.App.showToast("Resource deleted successfully.");
    await this.renderResourcesManager();
    this.renderStats();
    if (window.App) {
      await window.App.fetchResources();
      window.App.renderResources();
    }
  },

  async refreshResources() {
    window.App.showToast("Refreshing PDF resources...", "info");
    await this.renderResourcesManager();
    this.renderStats();
    if (window.App) {
      await window.App.fetchResources();
      window.App.renderResources();
    }
  }
};

window.AdminPortal = AdminPortal;
