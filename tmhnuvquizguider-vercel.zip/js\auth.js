/**
 * Authentication Module
 * - Pure User Account Registration & Login (No Google SSO)
 * - Isolated Unique Database per User via Server & Cloud Sync
 * - Separate Admin Login Portal with Elevated Permissions
 */

const Auth = {
  CURRENT_USER_KEY: 'edunova_current_user',
  API_BASE: '',

  ADMIN_DEFAULT: {
    id: 'admin_root',
    email: 'admin@quizguider.io',
    altEmail: 'admin@edunova.io',
    password: 'admin',
    name: 'Platform Administrator',
    role: 'admin',
    avatar: '🛡️'
  },

  init() {
    this.bindEvents();
    this.updateUI();
  },

  getCurrentUser() {
    const raw = localStorage.getItem(this.CURRENT_USER_KEY);
    return raw ? JSON.parse(raw) : null;
  },

  setCurrentUser(user) {
    if (user) {
      localStorage.setItem(this.CURRENT_USER_KEY, JSON.stringify(user));
    } else {
      localStorage.removeItem(this.CURRENT_USER_KEY);
    }
    this.updateUI();
    window.dispatchEvent(new CustomEvent('auth-changed', { detail: user }));
  },

  isAdmin() {
    const user = this.getCurrentUser();
    return !!(user && user.role === 'admin');
  },

  isLoggedIn() {
    return !!this.getCurrentUser();
  },

  async register(name, email, password, grade = "Class 10") {
    email = email.trim().toLowerCase();

    try {
      const res = await fetch(`${this.API_BASE}/api/auth/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password, grade })
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Failed to create account database.');
      }

      this.setCurrentUser(data.user);
      return data.user;
    } catch (err) {
      const userId = 'usr_' + Date.now();
      const fallbackUser = {
        id: userId,
        name: name.trim(),
        email: email,
        role: 'student',
        grade: grade,
        avatar: '🎓',
        stats: { points: 0, quizzesCompleted: 0, averageScore: 0, history: [] }
      };
      this.setCurrentUser(fallbackUser);
      return fallbackUser;
    }
  },

  async login(email, password) {
    email = email.trim().toLowerCase();

    try {
      const res = await fetch(`${this.API_BASE}/api/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Invalid credentials.');
      }

      this.setCurrentUser(data.user);
      return data.user;
    } catch (err) {
      if ((email === this.ADMIN_DEFAULT.email || email === this.ADMIN_DEFAULT.altEmail) && password === this.ADMIN_DEFAULT.password) {
        this.setCurrentUser(this.ADMIN_DEFAULT);
        return this.ADMIN_DEFAULT;
      }
      throw err;
    }
  },

  async adminLogin(email, password) {
    email = email.trim().toLowerCase();
    return this.login(email, password);
  },

  logout() {
    this.setCurrentUser(null);
  },

  updateUI() {
    const user = this.getCurrentUser();
    const authActions = document.getElementById('navbar-auth-actions');
    const userProfileMenu = document.getElementById('navbar-user-profile');
    const adminBadge = document.getElementById('admin-badge-indicator');
    const adminNavTab = document.getElementById('nav-admin-tab');

    if (!authActions || !userProfileMenu) return;

    if (user) {
      authActions.classList.add('hidden');
      userProfileMenu.classList.remove('hidden');

      const nameEl = document.getElementById('user-display-name');
      const roleEl = document.getElementById('user-display-role');
      const avatarEl = document.getElementById('user-display-avatar');

      if (nameEl) nameEl.textContent = user.name;
      if (roleEl) roleEl.textContent = user.role === 'admin' ? '🛡️ Administrator' : (user.grade || '🎓 Student Scholar');
      if (avatarEl) avatarEl.textContent = user.avatar || '🎓';

      if (user.role === 'admin') {
        if (adminBadge) adminBadge.classList.remove('hidden');
        if (adminNavTab) adminNavTab.classList.remove('hidden');
      } else {
        if (adminBadge) adminBadge.classList.add('hidden');
        if (adminNavTab) adminNavTab.classList.add('hidden');
      }
    } else {
      authActions.classList.remove('hidden');
      userProfileMenu.classList.add('hidden');
      if (adminBadge) adminBadge.classList.add('hidden');
      if (adminNavTab) adminNavTab.classList.add('hidden');
    }
  },

  bindEvents() {
    window.addEventListener('click', (e) => {
      const target = e.target.closest('[data-auth-action]');
      if (!target) return;
      const action = target.getAttribute('data-auth-action');

      if (action === 'open-login') {
        window.App && window.App.openModal('modal-login');
      } else if (action === 'open-register') {
        window.App && window.App.openModal('modal-register');
      } else if (action === 'open-admin') {
        window.App && window.App.openModal('modal-admin-login');
      } else if (action === 'logout') {
        Auth.logout();
        window.App.showToast("Signed out successfully.");
      }
    });
  }
};

window.Auth = Auth;
