/**
 * Quiz & Assessment Engine
 * - Timed quiz execution with countdown
 * - Submission directly posted to user's unique database
 * - PURE LIVE HONOR ROLL: Tracks actual quiz completions with zero example records
 * - In-browser Concept Flashcard Deck
 */

const QuizEngine = {
  currentQuiz: null,
  currentIndex: 0,
  userAnswers: {},
  timerInterval: null,
  timeRemainingSeconds: 0,
  activeFlashcardIndex: 0,
  API_BASE: '',

  init() {
    this.renderQuizList();
    this.renderLeaderboard();
    this.renderFlashcard();
  },

  getAllQuizzes() {
    const customQuizzes = JSON.parse(localStorage.getItem('edunova_custom_quizzes') || '[]');
    return [...(window.AppData ? window.AppData.quizzes : []), ...customQuizzes];
  },

  renderQuizList() {
    const container = document.getElementById('quiz-cards-container');
    if (!container) return;

    const quizzes = this.getAllQuizzes();
    container.innerHTML = quizzes.map(q => `
      <div class="glass-panel p-6 flex flex-col justify-between hover:border-indigo-400 transition-all duration-300">
        <div>
          <div class="flex items-center justify-between mb-3">
            <span class="badge-tag bg-indigo-100 text-indigo-700 dark:bg-indigo-900/50 dark:text-indigo-300">${q.category}</span>
            <span class="text-xs font-semibold text-amber-600 dark:text-amber-400">⏱️ ${q.timeLimitMinutes} Mins</span>
          </div>
          <h3 class="text-xl font-bold mb-2">${q.title}</h3>
          <p class="text-sm text-slate-500 dark:text-slate-400 mb-4">${q.description}</p>
          <div class="flex items-center gap-4 text-xs text-slate-500 dark:text-slate-400 mb-6">
            <span>📝 ${q.questions.length} Questions</span>
            <span>🎯 Passing: ${q.passingScore}%</span>
            <span>⭐ Level: ${q.difficulty}</span>
          </div>
        </div>
        <button onclick="QuizEngine.startQuiz('${q.id}')" class="w-full py-2.5 px-4 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg shadow-md transition flex items-center justify-center gap-2">
          <span>Start Assessment</span>
          <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>
        </button>
      </div>
    `).join('');
  },

  startQuiz(quizId) {
    const currentUser = window.Auth.getCurrentUser();
    if (!currentUser) {
      window.App.showToast("Please sign in or register to record your score on the Live Honor Roll!", "info");
      window.App.openModal('modal-login');
      return;
    }

    const quizzes = this.getAllQuizzes();
    const quiz = quizzes.find(q => q.id === quizId);
    if (!quiz) {
      window.App.showToast("Quiz not found", "error");
      return;
    }

    this.currentQuiz = quiz;
    this.currentIndex = 0;
    this.userAnswers = {};
    this.timeRemainingSeconds = quiz.timeLimitMinutes * 60;

    document.getElementById('quiz-view-lobby').classList.add('hidden');
    document.getElementById('quiz-view-active').classList.remove('hidden');
    document.getElementById('quiz-view-results').classList.add('hidden');

    document.getElementById('active-quiz-title').textContent = quiz.title;
    document.getElementById('active-quiz-total-q').textContent = quiz.questions.length;

    this.startTimer();
    this.renderCurrentQuestion();
  },

  startTimer() {
    clearInterval(this.timerInterval);
    const timerEl = document.getElementById('quiz-timer-display');

    const updateTimer = () => {
      const mins = Math.floor(this.timeRemainingSeconds / 60);
      const secs = this.timeRemainingSeconds % 60;
      timerEl.textContent = `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;

      if (this.timeRemainingSeconds <= 60) {
        timerEl.classList.add('timer-warning');
      } else {
        timerEl.classList.remove('timer-warning');
      }

      if (this.timeRemainingSeconds <= 0) {
        clearInterval(this.timerInterval);
        window.App.showToast("Time expired! Submitting answers...", "info");
        this.submitQuiz();
      } else {
        this.timeRemainingSeconds--;
      }
    };

    updateTimer();
    this.timerInterval = setInterval(updateTimer, 1000);
  },

  renderCurrentQuestion() {
    const q = this.currentQuiz.questions[this.currentIndex];
    const questionTextEl = document.getElementById('active-question-text');
    const optionsContainer = document.getElementById('active-question-options');
    const progressEl = document.getElementById('active-quiz-progress-bar');
    const currentNumEl = document.getElementById('active-quiz-current-num');

    if (!q) return;

    currentNumEl.textContent = this.currentIndex + 1;
    const progressPercent = ((this.currentIndex + 1) / this.currentQuiz.questions.length) * 100;
    progressEl.style.width = `${progressPercent}%`;

    questionTextEl.textContent = q.text;

    optionsContainer.innerHTML = q.options.map((opt, idx) => {
      const isSelected = this.userAnswers[this.currentIndex] === idx;
      return `
        <button onclick="QuizEngine.selectOption(${idx})" class="w-full text-left p-4 rounded-xl border transition-all flex items-center justify-between ${
          isSelected 
            ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-900 dark:text-indigo-200 ring-2 ring-indigo-500' 
            : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800/80 hover:border-indigo-300'
        }">
          <div class="flex items-center gap-3">
            <span class="w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs ${
              isSelected ? 'bg-indigo-600 text-white' : 'bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300'
            }">
              ${String.fromCharCode(65 + idx)}
            </span>
            <span class="font-medium">${opt}</span>
          </div>
          ${isSelected ? '<span class="text-indigo-600 dark:text-indigo-400 font-bold">✓</span>' : ''}
        </button>
      `;
    }).join('');

    const prevBtn = document.getElementById('quiz-btn-prev');
    const nextBtn = document.getElementById('quiz-btn-next');
    const submitBtn = document.getElementById('quiz-btn-submit');

    prevBtn.disabled = this.currentIndex === 0;
    if (this.currentIndex === this.currentQuiz.questions.length - 1) {
      nextBtn.classList.add('hidden');
      submitBtn.classList.remove('hidden');
    } else {
      nextBtn.classList.remove('hidden');
      submitBtn.classList.add('hidden');
    }
  },

  selectOption(idx) {
    this.userAnswers[this.currentIndex] = idx;
    this.renderCurrentQuestion();
  },

  nextQuestion() {
    if (this.currentIndex < this.currentQuiz.questions.length - 1) {
      this.currentIndex++;
      this.renderCurrentQuestion();
    }
  },

  prevQuestion() {
    if (this.currentIndex > 0) {
      this.currentIndex--;
      this.renderCurrentQuestion();
    }
  },

  async submitQuiz() {
    clearInterval(this.timerInterval);

    let correctCount = 0;
    const questions = this.currentQuiz.questions;

    questions.forEach((q, idx) => {
      if (this.userAnswers[idx] === q.correctIndex) {
        correctCount++;
      }
    });

    const scorePercentage = Math.round((correctCount / questions.length) * 100);
    const passed = scorePercentage >= this.currentQuiz.passingScore;

    const currentUser = window.Auth.getCurrentUser();
    if (currentUser) {
      try {
        const response = await fetch(`${this.API_BASE}/api/quiz/submit`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userId: currentUser.id,
            quizId: this.currentQuiz.id,
            scorePercentage,
            correctCount,
            totalQuestions: questions.length,
            answers: this.userAnswers
          })
        });

        const data = await response.json();
        if (data.success) {
          currentUser.stats = currentUser.stats || {};
          currentUser.stats.points = data.totalPoints;
          currentUser.stats.quizzesCompleted = data.quizzesCompleted;
          window.Auth.setCurrentUser(currentUser);
          window.App.showToast(`+${data.earnedPoints} Points added to your database!`);
        }
      } catch (err) {
        currentUser.stats = currentUser.stats || {};
        currentUser.stats.points = (currentUser.stats.points || 0) + (scorePercentage * 2);
        currentUser.stats.quizzesCompleted = (currentUser.stats.quizzesCompleted || 0) + 1;
        window.Auth.setCurrentUser(currentUser);
      }
    }

    document.getElementById('quiz-view-active').classList.add('hidden');
    document.getElementById('quiz-view-results').classList.remove('hidden');

    document.getElementById('results-score-percent').textContent = `${scorePercentage}%`;
    document.getElementById('results-correct-tally').textContent = `${correctCount} of ${questions.length} Correct`;

    const statusBadge = document.getElementById('results-status-badge');
    if (passed) {
      statusBadge.textContent = "PASSED - EXCELLENT PERFORMANCE";
      statusBadge.className = "inline-block px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300";
      window.App.triggerConfetti();
    } else {
      statusBadge.textContent = "NEEDS IMPROVEMENT - REVIEW & RETRY";
      statusBadge.className = "inline-block px-3 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300";
    }

    const reviewContainer = document.getElementById('results-explanations-list');
    reviewContainer.innerHTML = questions.map((q, idx) => {
      const userSelected = this.userAnswers[idx];
      const isCorrect = userSelected === q.correctIndex;
      return `
        <div class="p-4 rounded-xl border ${isCorrect ? 'border-emerald-300 bg-emerald-50/40 dark:bg-emerald-950/20' : 'border-rose-300 bg-rose-50/40 dark:bg-rose-950/20'} mb-3">
          <div class="flex items-start justify-between gap-3">
            <p class="font-semibold text-sm">Q${idx + 1}: ${q.text}</p>
            <span class="text-xs font-bold px-2 py-0.5 rounded ${isCorrect ? 'bg-emerald-600 text-white' : 'bg-rose-600 text-white'}">
              ${isCorrect ? 'Correct' : 'Incorrect'}
            </span>
          </div>
          <div class="mt-2 text-xs space-y-1">
            <p><span class="font-medium text-slate-500">Your Answer:</span> ${userSelected !== undefined ? q.options[userSelected] : '<i class="text-slate-400">Not Answered</i>'}</p>
            <p class="text-emerald-700 dark:text-emerald-400"><span class="font-medium">Correct Answer:</span> ${q.options[q.correctIndex]}</p>
            <p class="text-slate-600 dark:text-slate-300 mt-2 bg-white/70 dark:bg-slate-800/80 p-2.5 rounded-lg border border-slate-200 dark:border-slate-700"><span class="font-semibold text-indigo-600 dark:text-indigo-400">Explanation:</span> ${q.explanation}</p>
          </div>
        </div>
      `;
    }).join('');

    this.renderLeaderboard();
  },

  exitQuiz() {
    clearInterval(this.timerInterval);
    document.getElementById('quiz-view-active').classList.add('hidden');
    document.getElementById('quiz-view-results').classList.add('hidden');
    document.getElementById('quiz-view-lobby').classList.remove('hidden');
  },

  async renderLeaderboard() {
    const listEl = document.getElementById('leaderboard-rankings-list');
    if (!listEl) return;

    let honorRoll = [];

    try {
      const res = await fetch(`${this.API_BASE}/api/leaderboard`);
      if (res.ok) {
        const data = await res.json();
        honorRoll = data.honorRoll || [];
      }
    } catch (err) {
      const u = window.Auth.getCurrentUser();
      if (u && u.stats && u.stats.quizzesCompleted > 0) {
        honorRoll = [{
          rank: 1,
          name: u.name,
          score: u.stats.points || 0,
          quizzesTaken: u.stats.quizzesCompleted || 0,
          grade: u.grade || 'Student',
          avatar: u.avatar || '🎓'
        }];
      }
    }

    if (!honorRoll || honorRoll.length === 0) {
      listEl.innerHTML = `
        <div class="text-center py-8 px-4 rounded-xl border border-dashed border-slate-200 dark:border-slate-800">
          <div class="text-3xl mb-2">🎯</div>
          <p class="font-bold text-sm text-slate-700 dark:text-slate-300">No Live Test Scores Yet</p>
          <p class="text-xs text-slate-500 mt-1">Live tracking active. Take an assessment to be the first scholar on the Honor Roll!</p>
        </div>
      `;
      return;
    }

    listEl.innerHTML = honorRoll.map((item, index) => {
      const badgeColor = index === 0 ? 'bg-amber-100 text-amber-700 border-amber-300' :
                         index === 1 ? 'bg-slate-200 text-slate-700 border-slate-300' :
                         index === 2 ? 'bg-orange-100 text-orange-700 border-orange-300' : 'bg-slate-50 text-slate-500 border-slate-200 dark:bg-slate-800 dark:border-slate-700';
      return `
        <div class="flex items-center justify-between p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition">
          <div class="flex items-center gap-3">
            <span class="w-8 h-8 rounded-full border flex items-center justify-center font-bold text-sm ${badgeColor}">
              #${index + 1}
            </span>
            <div>
              <p class="font-bold text-sm flex items-center gap-2">
                <span>${item.avatar || '🎓'}</span>
                <span>${item.name}</span>
              </p>
              <p class="text-xs text-slate-400">${item.grade || 'Student Scholar'}</p>
            </div>
          </div>
          <div class="text-right">
            <span class="font-extrabold text-indigo-600 dark:text-indigo-400 text-sm">${item.score} pts</span>
            <p class="text-[10px] text-slate-400">${item.quizzesTaken} Attempt${item.quizzesTaken === 1 ? '' : 's'}</p>
          </div>
        </div>
      `;
    }).join('');
  },

  renderFlashcard() {
    const flashcards = window.AppData ? window.AppData.flashcards : [];
    if (!flashcards.length) return;

    const fc = flashcards[this.activeFlashcardIndex];
    const cardEl = document.getElementById('active-flashcard-element');
    const subjectEl = document.getElementById('flashcard-subject');
    const questionEl = document.getElementById('flashcard-question');
    const answerEl = document.getElementById('flashcard-answer');
    const counterEl = document.getElementById('flashcard-counter');

    if (!cardEl) return;

    cardEl.classList.remove('flipped');
    subjectEl.textContent = fc.subject;
    questionEl.textContent = fc.question;
    answerEl.textContent = fc.answer;
    counterEl.textContent = `${this.activeFlashcardIndex + 1} / ${flashcards.length}`;
  },

  toggleFlashcardFlip() {
    const cardEl = document.getElementById('active-flashcard-element');
    if (cardEl) {
      cardEl.classList.toggle('flipped');
    }
  },

  nextFlashcard() {
    const flashcards = window.AppData ? window.AppData.flashcards : [];
    if (this.activeFlashcardIndex < flashcards.length - 1) {
      this.activeFlashcardIndex++;
    } else {
      this.activeFlashcardIndex = 0;
    }
    this.renderFlashcard();
  },

  prevFlashcard() {
    const flashcards = window.AppData ? window.AppData.flashcards : [];
    if (this.activeFlashcardIndex > 0) {
      this.activeFlashcardIndex--;
    } else {
      this.activeFlashcardIndex = flashcards.length - 1;
    }
    this.renderFlashcard();
  }
};

window.QuizEngine = QuizEngine;
