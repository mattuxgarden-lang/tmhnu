/**
 * Application Data Store
 * Educational Platform data, Author details (Thaswin Kaarthi.A),
 * and School Details (T.M.H.N.U. Vidhyalaya Mat. Hr. Sec. School, Theni)
 * housed exclusively in the "Done By" section.
 */

const AppData = {
  platform: {
    name: "QuizGuider",
    tagline: "Next-Generation Interactive Learning & Assessment Ecosystem",
    description: "An open, state-of-the-art educational platform offering interactive STEM courses, real-time formula simulators, live code sandboxes, timed challenge assessments, and an academic resource library.",
    version: "2.0.0"
  },

  author: {
    name: "Thaswin Kaarthi.A",
    title: "Lead Creator & Platform Architect",
    role: "Developer • Student • STEM Innovator",
    badge: "Principal Author",
    avatar: "🚀",
    bio: "Student innovator and developer passionate about high-impact educational technologies, interactive digital learning, and algorithmic problem-solving. Conceptualized, architected, and built this complete educational platform.",
    quote: "Empowering every learner with interactive tools, instant assessments, and the joy of discovery.",
    skills: [
      "Full-Stack Web Architecture",
      "Interactive Learning Simulators",
      "Assessment & Quiz Engine Design",
      "UI/UX Design & Glassmorphism",
      "STEM Problem Solving"
    ]
  },

  school: {
    name: "Theni Melapettai Hindu Nadar Uravinmurai Vidhyalaya Matriculation Higher Secondary School",
    shortName: "T.M.H.N.U. Vidhyalaya Mat. Hr. Sec. School",
    location: "Edamal Street, Theni, Tamil Nadu - 625531",
    management: "Theni Melapettai Hindu Nadar Uravinmurai And All Nadar Saraswathi Educational Institutions",
    managementAddress: "1100 - Periyakulam Road, Theni - 625531",
    phone: "04546-252890",
    email: "tmhnujw@gmail.com",
    website: "https://www.tmhnuvidhyalaya.org",
    motto: "LEARN AND ACHIEVE",
    mottoQuote: "The learning acquired in one birth helps a man in seven (ஒருமைக்கண் தான் கற்ற கல்வி ஒருவற்கு எழுமையும் ஏமாப் புடைத்து)",
    mottoExplanation: "Education provides highly skilled people with values and leads us to the right path. As our motto, we provide Education with the framework of values which lead our children to the pinnacle of success and compete with the world.",
    established: "1977",
    strength: "Touched a new high of 2,000+ students from L.K.G to Std XII",
    preamble: "Our reputed, recognized management school Theni Melapettai Hindu Nadar Uravinmurai Matric Hr. Sec. School started with a handful of 105 kindergarten children in 1977. Now the strength has touched a new high of 2000 from L.K.G to Std XII. This development is due to the standard education rendered by our institution and its involvement with the public. It's a pride note that our school is the most Premier Educational Institution in Theni district functioning successfully at Edamal Street.",
    administration: {
      principal: {
        name: "Mrs. N. Pooranaselvi",
        qualifications: "M.A., B.Ed., (E) B.A., B.Ed., (H)",
        role: "Principal"
      },
      vicePrincipal: {
        name: "Mrs. C. Sangeetha",
        qualifications: "M.A., B.Ed.",
        role: "Vice-Principal"
      },
      officeBearers: [
        { role: "President", name: "Mr. A.S.G. Dharmarajan, B.A." },
        { role: "Vice-President", name: "Mr. A.S. Jeevagan" },
        { role: "General Secretary", name: "Mr. M.M. Anandavel, MBA." },
        { role: "Treasurer", name: "Mr. B. Ramachandran, MBA." },
        { role: "Secretary", name: "Mr. V.M.K.K. Ravindran, B.Sc., M.A., M.Ed." },
        { role: "Joint Secretary", name: "Mr. A.A.T.N.G. Arunchunaikani" },
        { role: "Joint Secretary", name: "Mr. A. Sankar" }
      ],
      executiveCommittee: [
        "Mr. S. Asokan", "Mr. K.T. Balasubramaniyan", "Mr. V.K.P. Gopi, B.Com.", "Mr. K.A.T. Karthikeyan, M.A.",
        "Mr. R. Pandikumar, B.Sc.", "Mr. G.S. Raja, B.Sc.", "Mr. A. Ramakrishnan", "Mr. T.M. Sambath",
        "Mr. M. Senthil Kumar @ Ashok", "Mr. C. Sowndarapandian, B.A.", "Mr. O.K.T. Vijay, B.A.", "Mr. R.V. Vijayakumar"
      ],
      schoolCommittee: [
        "Mr. M. Arun, DAE.", "Mr. R. Baskara Pandian", "Mr. G. Ganesan", "Mr. A.S.S. Jeyamani",
        "Mr. G. Kalatharan", "Mr. A.P. Karthikeyan", "Mr. A.T.S. Madasamy", "Mr. N.S. Mariyappan",
        "Mr. V. Murugesan", "Mr. M. Palanichamy", "Mr. K.A.S. Rameshbabu", "Mr. K. Sekar",
        "Mr. P. Senthil Kumar", "Mr. R. Vanniyarajan"
      ]
    },
    timings: [
      { section: "Kindergarten (K.G)", hours: "8:50 A.M. to 3:45 P.M." },
      { section: "Primary (Std I to Std V)", hours: "8:50 A.M. to 3:50 P.M." },
      { section: "High & Hr. Sec. (Std VI to Std XII)", hours: "8:50 A.M. to 3:50 P.M." },
      { section: "Administrative Office Hours", hours: "8:30 A.M. to 4:30 P.M." }
    ],
    terms: [
      { term: "I Term", duration: "June to September" },
      { term: "II Term", duration: "October to December" },
      { term: "III Term", duration: "January to April" }
    ],
    curriculum: [
      { level: "Kindergarten (LKG & UKG)", details: "Montessori Education. Children who completed 3 years are eligible. Emphasis on basic Communicative Language and social-emotional adjustment." },
      { level: "Primary & Middle (Std I to VIII)", details: "Matriculation Education with term-wise books and notebooks." },
      { level: "High & Higher Sec (Std IX to XII)", details: "Samacheer Education curriculum with practical laboratory training." }
    ],
    infrastructure: [
      {
        title: "Air-Conditioned Multimedia Theatre",
        desc: "State-of-the-art A/C audio-visual theatre enhancing English phonetic skills, interactive multimedia modules, and multi-skilled personality development.",
        icon: "🎬"
      },
      {
        title: "Modern Air-Conditioned Computer Lab",
        desc: "Equipped with 40 modernized individual workstations with intensive personal guidance — a legendary computing facility in Theni district.",
        icon: "💻"
      },
      {
        title: "Advanced Science Laboratories",
        desc: "Dedicated Physics, Chemistry, and Biology laboratories stimulating scientific inquiry, hands-on experimentation, and conceptual stability.",
        icon: "🔬"
      },
      {
        title: "Academic Reference Library",
        desc: "Comprehensive collection of encyclopedias, reference textbooks, and journals providing an inspirational environment for intellectual excellence.",
        icon: "📖"
      },
      {
        title: "₹15 Lakhs Mineral Water Plant",
        desc: "Pure and protective RO drinking water plant established at a milestone investment of ₹15 Lakhs, fulfilling pure water needs year-round.",
        icon: "💧"
      },
      {
        title: "Children's Amusement Park",
        desc: "Vibrant recreational park featuring Climber, Slide, Arch Swing, Merry-go-round, Rota Stride, and Snail Climber for fun, frolic, and rejuvenation.",
        icon: "🎪"
      },
      {
        title: "N.S. Hostels for Boys & Girls",
        desc: "Safe second homes: N.S. Girls Hostel @ Edamal Street & N.S. Boys Hostel @ Forest Road (Std III to XII) with hygienic, nutritive food and study atmosphere.",
        icon: "🏡"
      },
      {
        title: "Student Personality Development",
        desc: "Active wings in Cubs & Bulbuls, Junior Red Cross (JRC), National Service Scheme (NSS), National Green Corps (NGC), and Scouts & Guides.",
        icon: "🎖️"
      }
    ],
    rules: {
      students: [
        "Students must attend classes punctually with lessons prepared (arrive at least 5 minutes before first bell).",
        "Strictly adhere to the prescribed school uniform and clean footwear.",
        "English conversation is mandatory across the campus.",
        "Mobile phones, smartwatches, and all electronic gadgets are strictly prohibited.",
        "Students must not possess accounts on social media platforms like Facebook, Twitter, etc.",
        "Progress reports must be returned within 3 days duly signed by parents/guardians.",
        "Physical training (P.T.) and sports participation are compulsory for active health.",
        "Students with 100% attendance are honored with prestigious prizes and certificates."
      ],
      parents: [
        "School fees must be remitted on or before scheduled dates.",
        "Parents are prohibited from directly entering classrooms during working hours; contact through Principal only.",
        "Parents must daily inspect and sign their children's diary, homework, and test papers.",
        "Servants or guardians bringing lunch must wait at the designated gate until the lunch bell rings.",
        "Any change of residential address or contact number must be promptly notified to the Principal."
      ]
    }
  },

  announcements: [
    {
      id: "ann-1",
      title: "Interactive STEM Simulators & Code Sandbox Now Live",
      date: "October 16, 2026",
      tag: "Platform Feature",
      content: "Experience real-time interactive physics circuit modeling, quadratic root solving, and in-browser coding playgrounds directly inside the Courses tab.",
      pinned: true
    },
    {
      id: "ann-2",
      title: "All-India Science & Math Olympiad Mock Series",
      date: "October 14, 2026",
      tag: "Assessment",
      content: "Fresh timed mock assessments with detailed pedagogical solution rationales are now available in the Quiz Portal.",
      pinned: false
    },
    {
      id: "ann-3",
      title: "Academic Resource Hub Updated with 2026 Revision Papers",
      date: "October 10, 2026",
      tag: "Resources",
      content: "High-yield formula cheat sheets, past examination question banks, and Python quick references have been indexed for instant download.",
      pinned: false
    }
  ],

  courses: [
    {
      id: "course-math",
      title: "Mathematics Mastery (Classes 9–12)",
      category: "Mathematics",
      lessonsCount: 14,
      level: "Intermediate to Advanced",
      icon: "sigma",
      color: "from-blue-500 to-indigo-600",
      description: "Complete mastery of Algebra, Coordinate Geometry, Trigonometry, and Calculus with step-by-step interactive exercises.",
      lessons: [
        {
          id: "m-les-1",
          title: "Quadratic Equations & Roots",
          summary: "Understanding the nature of roots, discriminant (b² - 4ac), and quadratic formula.",
          content: "A quadratic equation has the general form: ax² + bx + c = 0 (where a ≠ 0).\nThe discriminant D = b² - 4ac dictates the nature of the roots:\n• If D > 0: Two distinct real roots\n• If D = 0: Two equal real roots\n• If D < 0: Complex conjugate roots.\nQuadratic Formula: x = (-b ± √(b² - 4ac)) / (2a)",
          interactiveTool: "quadratic-calc"
        },
        {
          id: "m-les-2",
          title: "Trigonometric Identities & Applications",
          summary: "Mastering sin²θ + cos²θ = 1, heights & distances, and angle sum formulas.",
          content: "Fundamental Identities:\n1. sin²θ + cos²θ = 1\n2. 1 + tan²θ = sec²θ\n3. 1 + cot²θ = cosec²θ\nDouble angle formulas: sin(2θ) = 2sinθcosθ, cos(2θ) = cos²θ - sin²θ.",
          interactiveTool: "trig-visualizer"
        },
        {
          id: "m-les-3",
          title: "Calculus: Differentiation Fundamentals",
          summary: "Derivatives as rate of change, power rule, product rule, and quotient rule.",
          content: "Power Rule: d/dx [xⁿ] = n·xⁿ⁻¹\nProduct Rule: d/dx [u·v] = u'v + uv'\nChain Rule: d/dx [f(g(x))] = f'(g(x))·g'(x)\nCritical points occur where f'(x) = 0 or undefined.",
          interactiveTool: "derivative-quiz"
        }
      ]
    },
    {
      id: "course-phys",
      title: "Physics & Natural Laws",
      category: "Physics",
      lessonsCount: 12,
      level: "Secondary & Higher Sec",
      icon: "atom",
      color: "from-cyan-500 to-blue-600",
      description: "Mechanics, Newton's Laws, Optics, Electromagnetism, and Modern Physics explained with everyday intuition.",
      lessons: [
        {
          id: "p-les-1",
          title: "Newton's Laws of Motion & Momentum",
          summary: "Inertia, F = ma, Action-Reaction, and Conservation of Linear Momentum.",
          content: "1st Law: Every object perseveres in its state of rest or uniform motion unless acted upon by an external net force.\n2nd Law: Net Force = mass × acceleration (F = dp/dt = ma).\n3rd Law: For every action, there is an equal and opposite reaction.",
          interactiveTool: "momentum-calc"
        },
        {
          id: "p-les-2",
          title: "Current Electricity & Ohm's Law",
          summary: "Electric potential, resistance, Ohm's law, and Kirchhoff's circuit rules.",
          content: "Ohm's Law: V = I · R (at constant temperature).\nSeries resistance: R_total = R₁ + R₂ + ...\nParallel resistance: 1/R_total = 1/R₁ + 1/R₂ + ...\nKirchhoff's Current Law (KCL): Sum of currents entering a junction equals sum of currents leaving.",
          interactiveTool: "ohms-sim"
        }
      ]
    },
    {
      id: "course-cs",
      title: "Computer Science & Python Coding",
      category: "Computer Science",
      lessonsCount: 16,
      level: "Beginner to Pro",
      icon: "code",
      color: "from-emerald-500 to-teal-700",
      description: "Learn logic building, algorithms, Python programming, and fundamentals of web technology.",
      lessons: [
        {
          id: "cs-les-1",
          title: "Variables, Data Types & Control Flow",
          summary: "Strings, Integers, Lists, Dictionaries, and conditional logic in Python.",
          content: "Python is dynamically typed and indentation-sensitive.\nExample:\nage = 16\nif age >= 18:\n    print('Eligible')\nelse:\n    print('Student')",
          interactiveTool: "python-playground"
        },
        {
          id: "cs-les-2",
          title: "Functions, Loops & Algorithms",
          summary: "Writing reusable functions, for/while loops, and binary search.",
          content: "def factorial(n):\n    if n <= 1:\n        return 1\n    return n * factorial(n - 1)\n\nprint(factorial(5)) # Output: 120",
          interactiveTool: "code-runner"
        }
      ]
    },
    {
      id: "course-chem",
      title: "Chemistry & Periodic Trends",
      category: "Chemistry",
      lessonsCount: 10,
      level: "Secondary & Higher Sec",
      icon: "flame",
      color: "from-amber-500 to-rose-600",
      description: "Atomic structure, chemical bonding, organic reactions, and interactive periodic table explorer.",
      lessons: [
        {
          id: "c-les-1",
          title: "Periodic Trends & Atomic Properties",
          summary: "Electronegativity, ionization energy, atomic radii, and electron affinity.",
          content: "Trends across a Period (left to right):\n• Atomic Radius decreases\n• Ionization Energy increases\n• Electronegativity increases\nTrends down a Group (top to bottom):\n• Atomic Radius increases\n• Ionization Energy decreases",
          interactiveTool: "periodic-explorer"
        }
      ]
    }
  ],

  flashcards: [
    {
      id: "fc-1",
      subject: "Physics",
      question: "What is Planck's constant (h) value and unit?",
      answer: "6.626 × 10⁻³⁴ Joule-seconds (J·s). It relates the energy of a photon to its frequency: E = hν."
    },
    {
      id: "fc-2",
      subject: "Mathematics",
      question: "What is Euler's Formula relating trigonometric functions to complex exponentials?",
      answer: "e^(iθ) = cos(θ) + i·sin(θ). When θ = π, it yields Euler's Identity: e^(iπ) + 1 = 0."
    },
    {
      id: "fc-3",
      subject: "Chemistry",
      question: "State Avogadro's constant and its physical meaning.",
      answer: "6.022 × 10²³ particles/mol. It is the number of constituent particles (atoms or molecules) in one mole of a substance."
    },
    {
      id: "fc-4",
      subject: "Computer Science",
      question: "What is the time complexity of Binary Search in a sorted array?",
      answer: "O(log n) time complexity, dividing the search interval in half with each comparison."
    },
    {
      id: "fc-5",
      subject: "School Stall Author",
      question: "Who developed this QuizGuider educational platform?",
      answer: "Designed and developed by Thaswin Kaarthi.A (T.M.H.N.U. Vidhyalaya Matric Hr. Sec. School, Theni)."
    }
  ],

  quizzes: [
    {
      id: "quiz-stem-1",
      title: "Science & Mathematics Excellence Challenge",
      category: "General STEM & Logic",
      difficulty: "Intermediate",
      timeLimitMinutes: 10,
      passingScore: 70,
      description: "Test your fundamental knowledge of Mathematics, Physics, Chemistry, and Logic.",
      questions: [
        {
          id: "q-1",
          text: "What is the discriminant of the quadratic equation: 2x² - 4x + 2 = 0?",
          options: ["D = 0", "D = 16", "D = -8", "D = 4"],
          correctIndex: 0,
          explanation: "Discriminant D = b² - 4ac = (-4)² - 4(2)(2) = 16 - 16 = 0. Hence, it has two equal real roots."
        },
        {
          id: "q-2",
          text: "Which of the following represents Newton's Second Law of Motion?",
          options: ["F = m × a", "E = m × c²", "V = I × R", "PV = nRT"],
          correctIndex: 0,
          explanation: "Newton's Second Law states that force equals rate of change of momentum, simplified as F = ma for constant mass."
        },
        {
          id: "q-3",
          text: "What is the pH of pure water at 25°C?",
          options: ["0", "7", "14", "1"],
          correctIndex: 1,
          explanation: "At 25°C, pure neutral water has equal concentrations of H⁺ and OH⁻ ions, yielding a pH of 7."
        },
        {
          id: "q-4",
          text: "In Python, which built-in function returns the number of items in an iterable?",
          options: ["count()", "size()", "len()", "length()"],
          correctIndex: 2,
          explanation: "The len() function returns the length (the number of items) of an object."
        },
        {
          id: "q-5",
          text: "What is the acceleration due to gravity (g) near Earth's surface?",
          options: ["9.8 m/s²", "6.67 m/s²", "3.14 m/s²", "12.5 m/s²"],
          correctIndex: 0,
          explanation: "Standard acceleration due to gravity near Earth's surface is approximately 9.80665 m/s²."
        }
      ]
    },
    {
      id: "quiz-olympiad-1",
      title: "Speed Math & Logical Reasoning Championship",
      category: "Math & Abacus Olympiad",
      difficulty: "Advanced",
      timeLimitMinutes: 8,
      passingScore: 75,
      description: "Sharpen your mental math and analytical reasoning with high-yield challenge questions.",
      questions: [
        {
          id: "oq-1",
          text: "What is the value of 99² calculated mentally via (100 - 1)²?",
          options: ["9801", "9811", "9701", "9901"],
          correctIndex: 0,
          explanation: "(100 - 1)² = 10000 - 200 + 1 = 9801."
        },
        {
          id: "oq-2",
          text: "If sin(θ) = 3/5, what is the value of tan(θ) for an acute angle θ?",
          options: ["3/4", "4/3", "4/5", "5/4"],
          correctIndex: 0,
          explanation: "By Pythagorean triplet (3, 4, 5): opposite=3, hypotenuse=5, adjacent=4. Hence tan(θ) = 3/4."
        },
        {
          id: "oq-3",
          text: "What is the sum of angles in a regular hexagon?",
          options: ["720°", "540°", "360°", "1080°"],
          correctIndex: 0,
          explanation: "Sum of interior angles = (n - 2) × 180° = (6 - 2) × 180° = 4 × 180° = 720°."
        }
      ]
    }
  ],

  resources: [],

  leaderboard: []
};

if (typeof window !== 'undefined') {
  window.AppData = AppData;
}
if (typeof module !== 'undefined' && module.exports) {
  module.exports = AppData;
}
